# logica
Programas da aula de Lógica da 1Info2
